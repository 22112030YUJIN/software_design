import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.text.*;
import java.util.*;

public class Missile {
        int x;
        int y;
        int speed;
        int damage;
        Missile(int x, int y, int damage) {
            this.x = x;
            this.y = y;
            this.speed = 6;
            this.damage = damage;
        }
        public int getDamage() {
        	return damage;
        }


        void move() {
            x += speed;
           
        }
        
        public int getX() {
            return x;
        }

        public int getY() {
            return y;
        }
    }
 
