import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

public class menu {
	BGM bgm;
	gameScreen gameScreen;
    public menu(BGM bgm, gameScreen gameScreen) {
        JFrame frame = new JFrame();
        frame.setLocation(400,500);    
       frame.setSize(400,400);
       
       //frame.setTitle("menu");
        frame.setLayout(null);
        frame.setUndecorated(true);
        
        this.gameScreen = gameScreen; 
       
        JCheckBox bgmCheck ;
        this.bgm = bgm;
        
        bgmCheck = new JCheckBox("BGM ON");
        bgmCheck.setBounds(155, 80, 140, 30);
        bgmCheck.setFont(new Font("Arial", Font.BOLD,20));
        bgmCheck.setSelected(true);
        bgmCheck.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    
                    bgm.play();
                } else {
                    
                    bgm.stop();
                }
            }
        });
        frame.add(bgmCheck);

        
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
       buttonPanel.setLayout(null);
       
        // 
       /* JButton saveBtn = new JButton("save");
        saveBtn.setBounds(150, 140, 100, 60);
        saveBtn.setFont(new Font("Arial", Font.BOLD,20));
        buttonPanel.add(saveBtn);
        frame.add(buttonPanel);
        frame.add(saveBtn);
        */
       
       
        JButton finishBtn = new JButton("return");
        finishBtn.setBounds(150, 180, 100, 60);
        finishBtn.setFont(new Font("Arial", Font.BOLD,20));
        finishBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
            	frame.setVisible(false);
            	
            	returnToGame();
            	//new startScreen();
            } 
            });
        buttonPanel.add(finishBtn);
        frame.add(buttonPanel);
        frame.add(finishBtn);     
        
        
        
        ImageIcon backIcon = new ImageIcon("exit_40.png");
        
        JButton  backBtn = new JButton(backIcon);
        backBtn.setBounds(280, 10, 100, 80);
        backBtn.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		frame.setVisible(false);
        		
        		gameScreen.gameOver();
        		
        	}
        });
        backBtn.setOpaque(false); 
        backBtn.setContentAreaFilled(false); 
        backBtn.setBorderPainted(false); 
        
        buttonPanel.add(backBtn);
        frame.add(buttonPanel);
        frame.add(backBtn);
       
        
     

        frame.setVisible(true);  
    }
    
    private void returnToGame() {
      
        gameScreen.requestFocusInWindow(); 
        gameScreen.resumeGame(); 
    }
    

}