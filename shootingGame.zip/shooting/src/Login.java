/*
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.util.*;
import java.io.*;

public class Login {
	private HashMap<String, String> userList;
    public Login() {
        JFrame frame = new JFrame();
        frame.setLocation(700,300);    //�� ȭ���� ����� ���� ��ġ�� ����ֱ�
        frame.setSize(400,200);
        frame.setTitle("login");
        frame.setLayout(null);

        
        
        JLabel IDLabel = new JLabel("���̵� : ");
        IDLabel.setSize(80,30);
        IDLabel.setLocation(70,30);
        IDLabel.setHorizontalAlignment(JLabel.CENTER);

        frame.add(IDLabel); //JFrame�� JLabel�� �߰�

        JTextField txt = new JTextField();
        txt.setSize(130,30);
        txt.setLocation(150,30);

        frame.add(txt);//JFrame�� JTextField�� �߰�

        JLabel PWLabel = new JLabel("��й�ȣ : ");
        PWLabel.setSize(80,30);
        PWLabel.setLocation(70,70);
        frame.add(PWLabel);

        //frame.add(PWLabel);

        txt = new JTextField();
        txt.setSize(130,30);
        txt.setLocation(150,70);
        frame.add(txt);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
       buttonPanel.setLayout(null);
       
        // ��ư 1 ����
        JButton loginBtn = new JButton("OK");
        loginBtn.setBounds(110, 110, 70, 30);
        loginBtn.setFont(new Font("Arial", Font.BOLD,15));
       
        
        buttonPanel.add(loginBtn);
        frame.add(buttonPanel);
        frame.add(loginBtn);
        
        JButton cancelBtn = new JButton("cancel");
        cancelBtn.setBounds(215, 110, 90, 30);
        cancelBtn.setFont(new Font("Arial", Font.BOLD,15));
        cancelBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
            	frame.setVisible(false);
            	
            } 
            });
            
        
        buttonPanel.add(cancelBtn);
        frame.add(buttonPanel);
        frame.add(cancelBtn);
        
        

        frame.setVisible(true);   
    }
}*/
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.*;

public class Login {

    private startScreen startScreen;

    public Login(startScreen startScreen) {
        this.startScreen = startScreen;
        JFrame frame = new JFrame();
        frame.setLocation(700, 300);
        frame.setSize(400, 200);
        frame.setTitle("Login");
        frame.setLayout(null);

        JLabel IDLabel = new JLabel("���̵� : ");
        IDLabel.setSize(80, 30);
        IDLabel.setLocation(70, 30);
        IDLabel.setHorizontalAlignment(JLabel.CENTER);

        frame.add(IDLabel);

        JTextField txtID = new JTextField();
        txtID.setSize(130, 30);
        txtID.setLocation(150, 30);

        frame.add(txtID);

        JLabel PWLabel = new JLabel("��й�ȣ : ");
        PWLabel.setSize(80, 30);
        PWLabel.setLocation(70, 70);
        frame.add(PWLabel);

        JTextField txtPW = new JTextField();
        txtPW.setSize(130, 30);
        txtPW.setLocation(150, 70);
        frame.add(txtPW);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(null);

        JButton loginBtn = new JButton("OK");
        loginBtn.setBounds(110, 110, 70, 30);
        loginBtn.setFont(new Font("Arial", Font.BOLD, 15));
        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = authenticateUser(txtID.getText(), txtPW.getText());
                if (username != null) {
                    startScreen.showUsername(username);
                    frame.dispose();
                } else {
                    JOptionPane.showMessageDialog(frame, "�߸��� ���̵� �Ǵ� ��й�ȣ�Դϴ�.", "����", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        buttonPanel.add(loginBtn);
        frame.add(buttonPanel);
        frame.add(loginBtn);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setBounds(215, 110, 90, 30);
        cancelBtn.setFont(new Font("Arial", Font.BOLD, 15));
        cancelBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        buttonPanel.add(cancelBtn);
        frame.add(buttonPanel);
        frame.add(cancelBtn);

        frame.setVisible(true);
    }

    private String authenticateUser(String id, String password) {
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("userList.txt"))) {
            while ((line = reader.readLine()) != null) {
                
                String[] userInfo = line.split(", ");
                
                String storedId = userInfo[0].trim();
                String storedPassword = userInfo[1].trim();
               
                if (storedPassword == null) {
                    // ���� ������ �߸��Ǿ� ��й�ȣ�� ���� ���
                    break;
                }
                storedPassword = storedPassword.trim();
                if (storedId.equals(id) && storedPassword.equals(password)) {
                    return storedId;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
