import java.text.DecimalFormat;

public class GameTimer {
    private long startTime;
    private DecimalFormat timeFormat;

    public GameTimer() {
        startTime = System.currentTimeMillis();
        timeFormat = new DecimalFormat("00");
    }

    public String getFormattedPlayTime() {
        long currentTime = System.currentTimeMillis();
        long elapsedTime = currentTime - startTime;

        long minutes = (elapsedTime / 1000) / 60;
        long seconds = (elapsedTime / 1000) % 60;

        return timeFormat.format(minutes) + ":" + timeFormat.format(seconds);
    }
}
