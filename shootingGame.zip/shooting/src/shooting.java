import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.text.*;
import java.util.*;
//import startScreen.BackgroundPanel;


public class shooting {
   public static void main(String[] args) {
      
      new startScreen();

   }
}

class gameScreen extends JFrame implements KeyListener, Runnable {
    private int width = 1000, height = 800;
    private int x, y;
    private boolean KeyUp = false;
    private boolean KeyDown = false;
    private boolean KeyLeft = false;
    private boolean KeyRight = false;
    private boolean KeySpace = false;
    
    private Thread th;
    private ImageIcon jet = null;
    private ImageIcon bg = null;
    private JPanel panel1;
    
    private GameTimer gameTimer;
    private JLabel timeLabel;
    
    private JButton menuBtn;
    
    private int totalMissile = 50; 
    private JLabel remainMSLabel;
    
    private ImageIcon Missile_img;
    
    private ArrayList<Missile> Missile_List = new ArrayList<>();
    BGM bgm =new BGM("bgm_W_ddown.wav", true);
    private ImageIcon enemy_img;

    private ArrayList<Enemy> enemy_List = new ArrayList<>();
    private long lastEnemySpawnTime;
    private long enemySpawnInterval = 2000; // �� ���� ���� (2��)
    private JLabel scoreLabel;
    private int score;
    public int currentStage=1;
   
    
private boolean paused = false;

    
    gameScreen() {
        init();
        start();
      
        setTitle("Shooting game");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(width, height);
        setLayout(null);

        jet = new ImageIcon("jet2222.png");
        bg = new ImageIcon("backGround2.png");
        
        
        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(null);
        
        panel1 = new JPanel() {
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                int imageWidth = jet.getIconWidth();
                int imageHeight = jet.getIconHeight();
                int panelWidth = getWidth();
                int panelHeight = getHeight();
                int drawX = x;
                int drawY = y;

                // �̹����� ȭ���� ����� �ʵ��� ��ǥ ����
                if (drawX < 0) {
                    drawX = 0;
                } else if (drawX + imageWidth > panelWidth) {
                    drawX = panelWidth - imageWidth;
                }

                if (drawY < 0) {
                    drawY = 0;
                } else if (drawY + imageHeight > panelHeight) {
                    drawY = panelHeight - imageHeight;
                }

                g.drawImage(bg.getImage(), 0, 0, getWidth(), getHeight(), null); 
                g.drawImage(jet.getImage(), drawX, drawY, this); 
                Draw_Missile(g); 

                Draw_Enemy(g);

            }
        };
        panel1.setBounds(0, 0, width, height);
        panel1.setFocusable(true);
        panel1.requestFocusInWindow();
        panel1.addKeyListener(this);

        add(panel1);
        
        
        
        panel1.setLayout(new BorderLayout());
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(null);
       
     
        ImageIcon menuIcon = new ImageIcon("menu_b70.png");
        menuBtn = new JButton(menuIcon);

        menuBtn.setBounds(780, 30, 200, 80);
        menuBtn.setFont(new Font("Arial", Font.BOLD,25));
        //loginBtn.setBackground(Color.white);
        menuBtn.setOpaque(false); // ������ �������� ����
        menuBtn.setContentAreaFilled(false); // ��ư ���� ������ �����ϰ� ����
        menuBtn.setBorderPainted(false); // ��ư �׵θ��� �׸��� �ʵ��� ����
        
        menuBtn.addActionListener(new ActionListener() {
               public void actionPerformed(ActionEvent e) {
   
                   pauseGame(); // ���� �Ͻ� ����
                   new menu(bgm,gameScreen.this);
               }
           });
        
        buttonPanel.add(menuBtn);
        panel1.add(menuBtn);
        panel1.add(buttonPanel);
      
        
        JLabel txtPanel = new JLabel();
        remainMSLabel = new JLabel();

        
        remainMSLabel.setBounds(750, 120, 200,30);
        remainMSLabel.setFont(new Font("Arial", Font.BOLD, 20));       
        txtPanel.add(remainMSLabel);
        panel1.add(remainMSLabel);
        panel1.add(txtPanel);
        updateRemainingMissilesLabel();  

        
        JLabel timePanel = new JLabel();
        gameTimer = new GameTimer();
        
        timeLabel = new JLabel();
        timeLabel.setBounds(750, 140, 200, 50);
        timeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        timePanel.add(timeLabel);
        ActionListener timerListener = new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                updatePlayTime();
            }
        };

        // 1�ʸ��� �÷��� �ð� ������Ʈ
        javax.swing.Timer timer = new javax.swing.Timer(1000, timerListener);
        timer.start();
        panel1.add(timeLabel);
        panel1.add(timePanel);
        
       
        JLabel stagePanel = new JLabel();
        JLabel stageLabel = new JLabel("stage 1");
        stageLabel.setBounds(50, 25, 200, 50);
        stageLabel.setFont(new Font("Arial", Font.BOLD, 25));
        
        stagePanel.add(stageLabel);
        panel1.add(stageLabel);
        panel1.add(stagePanel);


        JLabel scorePanel = new JLabel();

        scoreLabel = new JLabel();
        scoreLabel.setBounds(750, 170, 200, 50);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 20));
        scorePanel.add(scoreLabel);
        panel1.add(scoreLabel);
        panel1.add(scorePanel);

        setVisible(true);
        
        
    }
    
    gameScreen(Image selectedImage) {
        init();
        start();

        setTitle("Shooting game");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(width, height);
        setLayout(null);
        
        
        jet = new ImageIcon(selectedImage);
        bg = new ImageIcon("backGround2.png");

        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(null);
        
        panel1 = new JPanel() {
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                int imageWidth = jet.getIconWidth();
                int imageHeight = jet.getIconHeight();
                int panelWidth = getWidth();
                int panelHeight = getHeight();
                int drawX = x;
                int drawY = y;

                // �̹����� ȭ���� ����� �ʵ��� ��ǥ ����
                if (drawX < 0) {
                    drawX = 0;
                } else if (drawX + imageWidth > panelWidth) {
                    drawX = panelWidth - imageWidth;
                }

                if (drawY < 0) {
                    drawY = 0;
                } else if (drawY + imageHeight > panelHeight) {
                    drawY = panelHeight - imageHeight;
                }

                g.drawImage(bg.getImage(), 0, 0, getWidth(), getHeight(), null); 
                g.drawImage(jet.getImage(), drawX, drawY, this); 
                Draw_Missile(g);

                Draw_Enemy(g);

            }
        };
        panel1.setBounds(0, 0, width, height);
        panel1.setFocusable(true);
        panel1.requestFocusInWindow();
        panel1.addKeyListener(this);

        add(panel1);
        
        
        
        panel1.setLayout(new BorderLayout());
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(null);
       

        ImageIcon menuIcon = new ImageIcon("menu_b70.png");
        menuBtn = new JButton(menuIcon);

        menuBtn.setBounds(780, 30, 200, 80);
        menuBtn.setFont(new Font("Arial", Font.BOLD,25));
        //loginBtn.setBackground(Color.white);
        menuBtn.setOpaque(false); 
        menuBtn.setContentAreaFilled(false); 
        menuBtn.setBorderPainted(false); 
        
        menuBtn.addActionListener(new ActionListener() {
               public void actionPerformed(ActionEvent e) {
               
                   pauseGame(); 
                   new menu(bgm,gameScreen.this);
               }
           });
        
        buttonPanel.add(menuBtn);
        panel1.add(menuBtn);
        panel1.add(buttonPanel);
      
        
        JLabel txtPanel = new JLabel();
        remainMSLabel = new JLabel();

        
        remainMSLabel.setBounds(750, 120, 200,30);
        remainMSLabel.setFont(new Font("Arial", Font.BOLD, 20));       
        txtPanel.add(remainMSLabel);
        panel1.add(remainMSLabel);
        panel1.add(txtPanel);
        updateRemainingMissilesLabel();  

        
        JLabel timePanel = new JLabel();
        gameTimer = new GameTimer();
        
        timeLabel = new JLabel();
        timeLabel.setBounds(750, 140, 200, 50);
        timeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        timePanel.add(timeLabel);
        ActionListener timerListener = new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                updatePlayTime();
            }
        };

        javax.swing.Timer timer = new javax.swing.Timer(1000, timerListener);
        timer.start();
        panel1.add(timeLabel);
        panel1.add(timePanel);
        
       
        JLabel stagePanel = new JLabel();
        JLabel stageLabel = new JLabel("stage 1");
        stageLabel.setBounds(50, 25, 200, 50);
        stageLabel.setFont(new Font("Arial", Font.BOLD, 25));
        
        stagePanel.add(stageLabel);
        panel1.add(stageLabel);
        panel1.add(stagePanel);

        JLabel scorePanel = new JLabel();

        scoreLabel = new JLabel();
        scoreLabel.setBounds(750, 170, 200, 50);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 20));
        scorePanel.add(scoreLabel);
        panel1.add(scoreLabel);
        panel1.add(scorePanel);

        setVisible(true);
    }
    
    
    public void init() {
        x = 100;
        y = 300;

        score =0;
        Missile_img = new ImageIcon("missil_b45.png");
        enemy_img = new ImageIcon("enermy_g120.png");
        

    }

    
    public void start() {
        th = new Thread(this);
        th.start();
    }
    


    public void run() {
        try {
            randomEnemy();
            while (true) {
                if (!paused) {
                    keyProcess();
                    
                    updateEnemies();
                    MissileProcess();
                    updateRemainingMissilesLabel();

                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastEnemySpawnTime >= enemySpawnInterval) {
                        randomEnemy();
                        lastEnemySpawnTime = currentTime;
                    }
                    
                    for (Enemy enemy : enemy_List) {
                        enemy.move();
                    }
                }
                
                repaint();
                Thread.sleep(20);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
   
    

    
    public void Draw_Enemy(Graphics g) {
        for (Enemy enemy : enemy_List) {
            enemy.draw(g);
        }
    }
    
    
    private void randomEnemy() {
    	int x = width;
    	 int y = (int) (Math.random() * (height - 100));
        int speed = 2;
        int guage = (int) (Math.random() *(50-10+1))+10;
        Enemy enemy = new Enemy(x, y, speed,guage);
        enemy_List.add(enemy);
    }
    
    
    
    public boolean checkCollision(Enemy enemy) {
        int distanceX = Math.abs(x - enemy.getX());
        int distanceY = Math.abs(y - enemy.getY());
        int threshold = 70; // �浹 ���� ����

        return distanceX < threshold && distanceY < threshold;
    }

    
   
    
    public void MissileProcess() {
        if (KeySpace&& Missile_List.size()<totalMissile) {
        	int missileDamage = 10;
            Missile ms = new Missile(x, y,missileDamage);
            
           Missile_List.add(ms);
           new BGM("mfire_up.wav",false);
            updateRemainingMissilesLabel();
      
        }
       
    }
    
    public void updateEnemies() {
        Iterator<Enemy> enemyIterator = enemy_List.iterator();
        while (enemyIterator.hasNext()) {
            Enemy enemy = enemyIterator.next();
            enemy.move();

            // ���� �̻��� �浹 ���� Ȯ��
            Iterator<Missile> missileIterator = Missile_List.iterator();
            while (missileIterator.hasNext()) {
                Missile missile = missileIterator.next();
                if (enemy.checkCollision(missile)) {
                    missileIterator.remove(); // �̻��� ����
                    enemyIterator.remove(); // �� ����
                    score+=10;
                    new BGM("explo_up.wav", false);
                    break; // ���� �浹�� �̻����� �ϳ��� �� �̻� Ȯ���� �ʿ� �����Ƿ� �ݺ��� ����
                }
            }
        }
    }
    
    
    private void updateRemainingMissilesLabel() {
        if (remainMSLabel != null) {
           int remainingMissiles = totalMissile - Missile_List.size();

           remainMSLabel.setText("Remain missile: " + remainingMissiles);
          
        }
    }


    public void Draw_Missile(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        ArrayList<Missile> missilesToRemove = new ArrayList<>();

        for (Missile missile : Missile_List) {
            missile.move();
            g2d.drawImage(Missile_img.getImage(), missile.getX() + 100, missile.getY() + 30, this);

            Iterator<Enemy> enemyIterator = enemy_List.iterator();
            while (enemyIterator.hasNext()) {
                Enemy enemy = enemyIterator.next();
                if (enemy.checkCollision(missile)) {
                    missilesToRemove.add(missile);
                    if (enemy.isDestroyed()) {
                        score += 10;
                        scoreLabel.setText("Score: " + score);
                        enemyIterator.remove();
                    }
                    break;
                }
            }

            if (missile.getX() > width) {
                missilesToRemove.add(missile);
            }
        }

        Missile_List.removeAll(missilesToRemove);
    }

    
    private void updatePlayTime() {
        String formattedTime = gameTimer.getFormattedPlayTime();
        timeLabel.setText("Play time: " + formattedTime);
    }
    
    
    private void pauseGame() {
       paused = true;

       for (Enemy enemy : enemy_List) {
           enemy.pauseMovement();
       }   
    }
    
    
    public void resumeGame() {
    	paused = false;
    	
    	panel1.setFocusable(true);
        panel1.requestFocusInWindow();
    	for (Enemy enemy : enemy_List) {
            enemy.resumeMovement();
        }	
    }
    
    public void gameOver() {
        String playTime = gameTimer.getFormattedPlayTime();
        int finalScore = score;
        int stage = currentStage;

        new gameOver(playTime, finalScore, stage);
    }
    

    
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                KeyUp = true;
                break;
            case KeyEvent.VK_DOWN:
                KeyDown = true;
                break;
            case KeyEvent.VK_LEFT:
                KeyLeft = true;
                break;
            case KeyEvent.VK_RIGHT:
                KeyRight = true;
                break;
            case KeyEvent.VK_SPACE:
                KeySpace = true; 
                break;
        }
    }

    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                KeyUp = false;
                break;
            case KeyEvent.VK_DOWN:
                KeyDown = false;
                break;
            case KeyEvent.VK_LEFT:
                KeyLeft = false;
                break;
            case KeyEvent.VK_RIGHT:
                KeyRight = false;
                break;
            case KeyEvent.VK_SPACE:
                KeySpace = false; 
                break;
        }
    }

    public void keyTyped(KeyEvent e) {}
    
    
    public void keyProcess() {
        if (KeyUp) y -= 5;
        if (KeyDown) y += 5;
        if (KeyLeft) x -= 5;
        if (KeyRight) x += 5;
    }
}
 
