
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;


public class gameOver {
    public gameOver(String playTime, int score, int stage) {
        JFrame frame = new JFrame("Game Over");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800);
        frame.setLayout(null);
       
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.black);
        
        JLabel timeLabel = new JLabel("Play Time: " + playTime);
        timeLabel.setBounds(380, 100, 400, 100);
        timeLabel.setFont(new Font("Arial", Font.BOLD,30));
        timeLabel.setForeground(Color.white);
        panel.add(timeLabel);
        
        JLabel scoreLabel = new JLabel("Score: " + score);
        scoreLabel.setBounds(410, 250, 200, 100);
        scoreLabel.setFont(new Font("Arial", Font.BOLD,30));
        scoreLabel.setForeground(Color.white);
        panel.add(scoreLabel);
        
        
        JLabel stageLabel = new JLabel("Stage: " + stage);
        stageLabel.setBounds(410, 400, 200, 100);
        stageLabel.setFont(new Font("Arial", Font.BOLD,30));
        stageLabel.setForeground(Color.white);
        panel.add(stageLabel);
        
        JButton mainBtn = new JButton("MAIN");
        mainBtn.setBounds(50, frame.getHeight() - 200, 200, 80);
        mainBtn.setFont(new Font("Arial", Font.BOLD, 30));

        mainBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
            	new MainInfo();
            }
        });
        panel.add(mainBtn);
        
        JButton exitBtn = new JButton("END");
        exitBtn.setBounds(frame.getWidth() - 250, frame.getHeight() - 200, 200, 80);
        exitBtn.setFont(new Font("Arial", Font.BOLD, 25));
        exitBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //frame.setVisible(false);
            	System.exit(0);
            }
        });
        panel.add(exitBtn);
        
        panel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        
        frame.add(panel);
        frame.setVisible(true);
    }
}