

import javax.swing.*;
import javax.swing.event.*;

//import MainInfo.BackgroundPanel;

import java.awt.*;
import java.awt.event.*;

public class characterScreen {
    private ImageLabel selectedLabel;

    public characterScreen() {
        JFrame frame = new JFrame("Image Selection");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800);

        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(null);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(null);

        backgroundPanel.add(buttonPanel, BorderLayout.CENTER);

        ImageLabel jet1 = new ImageLabel("jet1111.png");
        jet1.setBounds(40, 180, 300, 300);
        backgroundPanel.add(jet1);

        jet1.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                setSelectedLabel(jet1);
                
            }
        });

        ImageLabel jet2 = new ImageLabel("jet2222.png");
        jet2.setBounds(340, 180, 300, 300);
        backgroundPanel.add(jet2);

        jet2.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                setSelectedLabel(jet2);
            }
        });

        ImageLabel jet3 = new ImageLabel("jet3333.png");
        jet3.setBounds(640, 180, 300, 300);
        backgroundPanel.add(jet3);

        jet3.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                setSelectedLabel(jet3);
            }
        });

        JButton okBtn = new JButton("OK");
        okBtn.setBounds(frame.getWidth() - 250, frame.getHeight() - 200, 200, 80);
        okBtn.setFont(new Font("Arial", Font.BOLD, 25));
        buttonPanel.add(okBtn);

        backgroundPanel.add(okBtn);

        okBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                if (selectedLabel != null) {
                    Image selectedImage = selectedLabel.getImage();
                    new gameScreen(selectedImage);
                } else {
                    new gameScreen(); // �̹����� ���õ��� ���� ���
                }
            }
        });

        backgroundPanel.add(buttonPanel);
        frame.add(backgroundPanel);
        frame.setVisible(true);
    }

    private void setSelectedLabel(ImageLabel label) {
        if (selectedLabel != null) {
            selectedLabel.setSelected(false);
        }
        selectedLabel = label;
        selectedLabel.setSelected(true);
    }

    static class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel() {
            backgroundImage = new ImageIcon("backGround4.png").getImage();
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

    class ImageLabel extends JLabel {
        private Image image;
        private boolean selected;
        private boolean mouseOver;

        public ImageLabel(String imagePath) {
            image = new ImageIcon(imagePath).getImage();
            selected = false;
            mouseOver = false;

            addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    setSelected(true);
                    setSelectedLabel(ImageLabel.this);
                }

                public void mouseEntered(MouseEvent e) {
                    mouseOver = true;
                    repaint();
                }

                public void mouseExited(MouseEvent e) {
                    mouseOver = false;
                    repaint();
                }
            });
        }

        public void setSelected(boolean selected) {
            this.selected = selected;
            repaint();
        }

        public Image getImage() {
            return image;
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (selected || mouseOver) {
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                setBorder(BorderFactory.createLineBorder(Color.GREEN, 2));
            } else {
                int x = (getWidth() - image.getWidth(this)) / 2;
                int y = (getHeight() - image.getHeight(this)) / 2;
                g.drawImage(image, x, y, this);
                setBorder(null);
            }
        }
    }
}
