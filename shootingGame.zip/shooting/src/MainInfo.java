//�Ϸ�
import javax.swing.*;
import javax.swing.event.*;

//import startScreen.BackgroundPanel;

import java.awt.*;
import java.awt.event.*;

public class MainInfo {
	MainInfo(){
	JFrame frame = new JFrame("Main");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(1000, 800);

   
    BackgroundPanel backgroundPanel = new BackgroundPanel();
    backgroundPanel.setLayout(new BorderLayout());


   
    JPanel buttonPanel = new JPanel();
    buttonPanel.setOpaque(false);
   buttonPanel.setLayout(null);
   
    
    JButton characterBtn = new JButton("Character");
    characterBtn.setBounds(40, frame.getHeight() - 200, 200, 80);
    characterBtn.setFont(new Font("Arial", Font.BOLD,25));
    //loginBtn.setBackground(Color.white);
    buttonPanel.add(characterBtn);

    characterBtn.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e) {
        	frame.setVisible(false);
        	new characterScreen();
        } 
        });
    
 
    
  
    JButton startBtn = new JButton("Start");
    startBtn.setBounds(frame.getWidth() - 250, frame.getHeight() - 200, 200, 80);
    startBtn.setFont(new Font("Arial", Font.BOLD,25));
    buttonPanel.add(startBtn);
    
    startBtn.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e) {
        	frame.setVisible(false);
        	new gameScreen();
        } 
        });
	
    backgroundPanel.add(buttonPanel);
    frame.add(backgroundPanel);
    frame.setVisible(true);
	
	}
	static class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel() {
           
            backgroundImage = new ImageIcon("backGround4.png").getImage();
        }


        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

          
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
