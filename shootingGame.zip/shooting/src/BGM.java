import javax.sound.sampled.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class BGM {
    private Clip clip;

    public BGM(String file,boolean Loop) {
    
    	try {

    	AudioInputStream ais = AudioSystem.getAudioInputStream(new BufferedInputStream(new FileInputStream(file)));
    	clip = AudioSystem.getClip();
    	clip.open(ais);
    	clip.start();
    	if ( Loop) clip.loop(-1);

    	//Loop ����true�� ������������ѹݺ���ŵ�ϴ�.

    	} catch (Exception e) {
    	e.printStackTrace();
    	}
    	}

    public void play() {
        if (clip != null && !clip.isRunning()) {
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
    }

    public void stop() {
        if (clip != null && clip.isRunning()) {
            clip.stop();
            clip.setFramePosition(0);
        }
    }

    public boolean isPlaying() {
        return clip != null && clip.isRunning();
    }
}