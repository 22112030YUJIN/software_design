
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class startScreen {
    BGM bgm;
    private JLabel userLabel;
    JFrame frame;

    startScreen() {
        frame = new JFrame("shooting game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800);

        // ��� �̹��� �г� ����
        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(null);

        // ���� ���̺� ����
        JLabel titleLabel = new JLabel("Shooting Game");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 80));
        titleLabel.setBounds(frame.getWidth() / 2 - 300, 100, 600, 90);
        backgroundPanel.add(titleLabel);

        // ��ư �г� ����
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(null);

        // ��ư 1 ����
        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(40, frame.getHeight() - 200, 200, 80);
        loginBtn.setFont(new Font("Arial", Font.BOLD, 25));
        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                startScreen startScreen = new startScreen();
                new Login(startScreen);
            }
        });
        buttonPanel.add(loginBtn);

        // ��ư 2 ����
        JButton startBtn = new JButton("Start");
        startBtn.setBounds(700, frame.getHeight() - 200, 200, 80);
        startBtn.setFont(new Font("Arial", Font.BOLD, 25));
        buttonPanel.add(startBtn);

        startBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new MainInfo();
            }
        });

     /*
        JButton loadBtn = new JButton("Load");
        loadBtn.setBounds(frame.getWidth() - 250, frame.getHeight() - 150, 200, 80);
        loadBtn.setFont(new Font("Arial", Font.BOLD, 25));

        loadBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new load();
            }
        });
        buttonPanel.add(loadBtn);
*/
        // userLabel ����
        userLabel = new JLabel();
        userLabel.setBounds(frame.getWidth() - 230, frame.getHeight() - 330, 200, 30);
        userLabel.setFont(new Font("Arial", Font.BOLD, 20));

        buttonPanel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        buttonPanel.add(loginBtn);
        buttonPanel.add(startBtn);
  //      buttonPanel.add(loadBtn);
        backgroundPanel.add(buttonPanel);
        backgroundPanel.add(userLabel);
        frame.add(backgroundPanel);

        frame.setVisible(true);
    }


    static class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel() {
    
            backgroundImage = new ImageIcon("backGround.png").getImage();
        }


        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

    private void playBGM() {
        if (!bgm.isPlaying()) {
            bgm.play();
        }
    }

    public void showUsername(String username) {
        userLabel.setText("userName: " + username);
    }
}
