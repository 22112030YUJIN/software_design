import java.awt.Color;
import java.awt.Graphics;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.text.*;
import java.util.*;

import javax.swing.ImageIcon;

public class Enemy {
    private int x;
    private int y;
    private int speed;
    private boolean isDestroyed;
    private ImageIcon enemy_img;
    private int health;
    private boolean movementPaused = false;
    
    
    Enemy(int x, int y, int speed, int health) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.health = health;
        this.isDestroyed=false;
        this.enemy_img = new ImageIcon("enermy_g120.png");
    }
    
    public int getHealth() {
    	return health;
    }
    public void setHealth(int health) {
    	this.health = health;
    }
    
    
    public void pauseMovement() {
        movementPaused = true;
    }

    public void resumeMovement() {
        movementPaused = false;
    }

    public void move() {
     if(!movementPaused)
    	x -= speed;
    }

    public void draw(Graphics g) {
    	if (!isDestroyed) {       
            g.drawImage(enemy_img.getImage(), x, y, null);
            g.setColor(Color.RED);
            g.fillRect(x, y - 10, health, 5); // ���� ü���� ǥ���ϴ� ������ ���簢�� �׸���
        }
    }
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    public boolean isDestroyed() {
        return isDestroyed;
    }
    
    public void checkDestroyed() {
        if (health <= 0) {
            isDestroyed = true;
        }
    }
    
    


    public boolean checkCollision(Missile missile) {
        if (!isDestroyed && Math.abs(x - missile.getX()) < 50 && Math.abs(y - missile.getY()) < 50) {
            health -= missile.getDamage(); // �̻����� ������ ��ŭ ü�� ����
            checkDestroyed(); // ü�¿� ���� �ı� ���� Ȯ��
            return true;
        }
        return false;
    }
}